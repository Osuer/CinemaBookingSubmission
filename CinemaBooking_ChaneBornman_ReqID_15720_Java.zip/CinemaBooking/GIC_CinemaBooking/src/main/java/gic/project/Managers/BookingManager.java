package gic.project.Managers;

import gic.project.CinemaLayouts.Movie;
import gic.project.CinemaLayouts.Seat;

public class BookingManager {

    private final Movie movie;

    public BookingManager(Movie movie){
        this.movie = movie;
    }

    public Seat[][] bookDefaultSeats(Seat[][] seatMap, int numberOfSeatsToBook, int row){
        int numberOfSeatsBooked = 0;
        int middle = movie.getSeatsPerRow() / 2;
        int leftIndex = middle - 1;
        int rightIndex = middle;

        while ((leftIndex >= 0 || rightIndex < movie.getSeatsPerRow()) && numberOfSeatsBooked <= numberOfSeatsToBook - 1) {
            if (rightIndex < movie.getSeatsPerRow() && numberOfSeatsBooked < numberOfSeatsToBook) {
                if (!seatMap[row][rightIndex].isBooked()){
                    seatMap[row][rightIndex].setBooked(true);
                    seatMap[row][rightIndex].setBookingId(movie.getLastBookingId());
                    numberOfSeatsBooked++;
                }
                rightIndex++;
            }

            if (leftIndex >= 0 && numberOfSeatsBooked < numberOfSeatsToBook) {
                if (!seatMap[row][leftIndex].isBooked()){
                    seatMap[row][leftIndex].setBooked(true);
                    seatMap[row][leftIndex].setBookingId(movie.getLastBookingId());
                    numberOfSeatsBooked++;
                }
                leftIndex--;
            }
        }

        if (numberOfSeatsBooked != numberOfSeatsToBook){
            if (row - 1 < 0){
                bookDefaultSeats(seatMap, numberOfSeatsToBook - numberOfSeatsBooked, movie.getRows() - 1);
            } else {
                bookDefaultSeats(seatMap, numberOfSeatsToBook - numberOfSeatsBooked, row - 1);
            }
        }
        return seatMap;
    }

    public Seat[][] bookCustomSeats(Seat[][] seatMap, int numberOfSeatsToBook, int row, int startingSeatSelection ){
        int numberOfSeatsBooked = 0;

        while (numberOfSeatsBooked < numberOfSeatsToBook && startingSeatSelection < movie.getSeatsPerRow()){
            if (!seatMap[row][startingSeatSelection].isBooked()){
                seatMap[row][startingSeatSelection].setBooked(true);
                seatMap[row][startingSeatSelection].setBookingId(movie.getLastBookingId());
                numberOfSeatsBooked++;
            } else {
                startingSeatSelection++;
            }
        }

        if (startingSeatSelection >= movie.getSeatsPerRow()){
            numberOfSeatsToBook = numberOfSeatsToBook - numberOfSeatsBooked;
            if (row - 1 < 0){
                bookDefaultSeats(seatMap, numberOfSeatsToBook, movie.getRows() - 1);
            } else {
                bookDefaultSeats(seatMap, numberOfSeatsToBook, row - 1);
            }
        }
        return seatMap;
    }

}
