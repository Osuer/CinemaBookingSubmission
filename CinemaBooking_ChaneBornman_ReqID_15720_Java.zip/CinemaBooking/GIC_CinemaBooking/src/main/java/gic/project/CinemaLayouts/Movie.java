package gic.project.CinemaLayouts;

import gic.project.Enums.RowEnum;

import java.util.*;
import java.util.stream.Collectors;

public class Movie {

    private final String movieTitle;
    private int availableSeats;
    private final int rows;
    private final int seatsPerRow;
    private Seat[][] seatMap;
    private final List<String> bookingIds;
    private Map<Character, Integer> rowMap;

    public Movie(String movieTitle, int rows, int seatsPerRow){
        this.movieTitle = movieTitle;
        this.rows = rows;
        this.seatsPerRow = seatsPerRow;
        this.availableSeats = rows*seatsPerRow;
        this.bookingIds = new ArrayList<>();
        initSeatMap(rows, seatsPerRow);
        initializeRowMap(rows);
    }

     void initializeRowMap(int totalRows) {
        RowEnum[] values = RowEnum.values();
        rowMap = new HashMap<>();
        for (int i = 0; i < totalRows; i++) {
            rowMap.put(values[totalRows - i - 1].name().charAt(0), i);
        }
        System.out.println();
    }

    public Optional<Integer> getRowIndex(char rowLabel) {
        return Optional.ofNullable(rowMap.get(rowLabel));
    }

    public Optional<Character> getRowLabel(int row){
        List<Character> character = rowMap.entrySet().stream()
            .filter(entry -> entry.getValue().equals(row))
            .map(Map.Entry::getKey)
            .collect(Collectors.toList());

        if (character.isEmpty()){
            return Optional.empty();
        }
        return Optional.of(character.get(0));
    }

    public Seat[][] copySeatMap(){
        Seat[][] copy = new Seat[seatMap.length][];
        for (int i = 0; i < seatMap.length; i++) {
            copy[i] = new Seat[seatMap[i].length];
            for (int j = 0; j < seatMap[i].length; j++) {
                copy[i][j] = new Seat(seatMap[i][j]);
            }
        }
        return copy;
    }

    public String generateBookingId(){
        bookingIds.add(String.format("%s%04d", "GIC", bookingIds.size() + 1));
        return getLastBookingId();
    }

    public List<String> getBookingIds(){
        return this.bookingIds;
    }

    public String getLastBookingId(){
        return this.bookingIds.get(bookingIds.size() - 1);
    }

    public int getRows() {
        return rows;
    }

    public int getSeatsPerRow() {
        return seatsPerRow;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public int getAvailableSeats() {
        return availableSeats;
    }

    public void setAvailableSeats(int availableSeats){
        this.availableSeats = availableSeats;
    }

    public Seat[][] getSeatMap() {
        return seatMap;
    }

    public void setSeatMap(Seat[][] seatMap) {
       this.seatMap = seatMap;
    }

    private void initSeatMap(int rows, int seatsPerRow){
        seatMap = new Seat[rows][seatsPerRow];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < seatsPerRow; j++) {
                seatMap[i][j] = new Seat();
            }
        }
    }

}
