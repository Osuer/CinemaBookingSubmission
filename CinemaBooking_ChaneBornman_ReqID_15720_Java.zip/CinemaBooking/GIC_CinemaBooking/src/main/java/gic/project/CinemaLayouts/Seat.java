package gic.project.CinemaLayouts;

public class Seat {

    private boolean isBooked;
    private String bookingId;

    public Seat(){
        this.isBooked = false;
        this.bookingId = "";
    }

    public Seat(Seat other) {
        this.isBooked = other.isBooked;
        this.bookingId = other.bookingId;
    }

    public boolean isBooked() {
        return isBooked;
    }

    public void setBooked(boolean booked) {
        isBooked = booked;
    }

    public String getBookingId() {
        return bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }
}
