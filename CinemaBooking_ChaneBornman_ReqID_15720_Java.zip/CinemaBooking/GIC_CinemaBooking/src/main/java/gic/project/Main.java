package gic.project;

import gic.project.Managers.ClientManager;

public class Main {
    public static void main(String[] args) {
        ClientManager clientManager = new ClientManager();
        clientManager.initiateUserInteraction();
    }
}