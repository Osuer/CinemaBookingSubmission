package gic.project.Managers;

import gic.project.CinemaLayouts.Movie;
import gic.project.CinemaLayouts.Seat;
import gic.project.Enums.RowEnum;
import gic.project.Printers.Printer;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class ClientManager {

    private final Printer printer = new Printer();
    private final Map<String, String> regexPatternsForValidInputs = new HashMap<>(){{
        put("Movie Definition","^(.*\\D)\\s+[1-9]\\d*\\s+[1-9]\\d*(\\s+[1-9]\\d*)?$");
        put("Seat Booking","^[A-Z]\\d{2}$");
        put("Number of Seats","^[1-9]\\d*$");
    }};
    private final int maxRows = RowEnum.values().length;
    private final int maxSeatsPerRow = 50;
    private final Scanner scanner;

    public ClientManager(){
        this.scanner = new Scanner(System.in);
    }

    public Map<String, String> getRegexPatternsForValidInputs(){
        return this.regexPatternsForValidInputs;
    }

    public void initiateUserInteraction(){
        printer.printMovieSeatMapDefinition();
        String userInput = scanner.nextLine();
        if (isValidInput(userInput, regexPatternsForValidInputs.get("Movie Definition"))){
            String[] userInputForMovieAndSeatingMap = userInput.split(" ");
            StringBuilder movieTitle = new StringBuilder();
            for (int i = 0; i < userInputForMovieAndSeatingMap.length - 2; i++) {
                movieTitle.append(userInputForMovieAndSeatingMap[i]).append(" ");
            }

            int rows = Integer.parseInt(userInputForMovieAndSeatingMap[userInputForMovieAndSeatingMap.length - 2]);
            int seatsPerRow = Integer.parseInt(userInputForMovieAndSeatingMap[userInputForMovieAndSeatingMap.length - 1]);

            if ((isValidSeatMapInput(rows, seatsPerRow))) {
                Movie movie = new Movie(movieTitle.toString().trim(), rows, seatsPerRow);
                showMenuScreen(movie);
            } else {
                initiateUserInteraction();
            }
        } else {
            printer.printInvalidInput();
            initiateUserInteraction();
        }
    }

    private void showMenuScreen(Movie movie){
        boolean exitMenu = false;
        while (!exitMenu) {
            boolean validInput = false;
            int selection = 0;
            while (!validInput) {
                printer.printWelcomeMessage(movie);
                try {
                    selection = Integer.parseInt(scanner.nextLine());
                    validInput = true;
                } catch (NumberFormatException e) {
                    printer.printNotValidMenuOption();
                }
            }
            switch (selection) {
                case 1:
                    showBookTicketsMenuScreen(movie);
                    break;

                case 2:
                    showCheckBookingMenuScreen(movie);
                    break;

                case 3:
                    exitMenu = true;
                    printer.printGoodbyeMessage();
                    break;

                default:
                    printer.printNotValidMenuOption();
            }
        }
    }

    private void showBookTicketsMenuScreen(Movie movie) {
        printer.printTicketBookingMenu();
        String userInput = scanner.nextLine();
        int numberOfSeatsToBook;
        if (!userInput.isBlank()) {
            if (isValidInput(userInput, regexPatternsForValidInputs.get("Number of Seats") )){
                numberOfSeatsToBook = Integer.parseInt(userInput);
                if (numberOfSeatsToBook <= movie.getAvailableSeats()) {
                    BookingManager bookingManager = new BookingManager(movie);
                    String bookingId = movie.generateBookingId();
                    Seat[][] reservationSeatMap = movie.copySeatMap();
                    bookingManager.bookDefaultSeats(reservationSeatMap, numberOfSeatsToBook, reservationSeatMap.length - 1);
                    printer.printBookingReserved(movie, numberOfSeatsToBook);
                    printer.printReservation(movie, reservationSeatMap, bookingId);
                    printer.printConfirmReservation();
                    userInput = scanner.nextLine();
                    while (!userInput.isBlank()){
                        while(!isValidInput(userInput, regexPatternsForValidInputs.get("Seat Booking"))){
                            printer.printInvalidSeatBooking();
                            userInput = scanner.nextLine();
                        }
                        while (movie.getRowIndex(userInput.charAt(0)).isEmpty()){
                            printer.printInvalidSeatBooking();
                            userInput = scanner.nextLine();
                        }
                        int startingRow = movie.getRowIndex(userInput.charAt(0)).get();
                        int startingSeatSelection = Integer.parseInt(userInput.substring(1)) - 1;
                        reservationSeatMap = movie.copySeatMap();
                        bookingManager.bookCustomSeats(reservationSeatMap, numberOfSeatsToBook, startingRow, startingSeatSelection);
                        printer.printReservation(movie, reservationSeatMap, bookingId);
                        printer.printConfirmReservation();
                        userInput = scanner.nextLine();
                    }
                    printer.printBookingIdConfirmed(bookingId);
                    movie.setSeatMap(reservationSeatMap);
                    movie.setAvailableSeats(movie.getAvailableSeats() - numberOfSeatsToBook);
                } else {
                    printer.printNotEnoughSeatsAvailable(movie.getAvailableSeats());
                    showBookTicketsMenuScreen(movie);
                }
            } else {
                printer.printInvalidInput();
                showBookTicketsMenuScreen(movie);
            }
        }
    }

    private void showCheckBookingMenuScreen(Movie movie){
        printer.printViewBookingMenu();
        String bookingId = scanner.nextLine();
        while (!bookingId.isBlank()){
            if (!movie.getBookingIds().contains(bookingId)) {
                printer.printInvalidBookingId();
            } else {
                printer.printBooking(movie, bookingId);
            }
            printer.printViewBookingMenu();
            bookingId = scanner.nextLine();
        }
    }

    private boolean isValidInput(String input, String regexToMatch){
        return input.matches(regexToMatch);
    }

    private boolean isValidSeatMapInput(int rows, int seatsPerRow){
        boolean valid = true;
        if (rows > maxRows){
            printer.printTooManyRows(maxRows);
            valid = false;
        }
        if (seatsPerRow > maxSeatsPerRow){
            printer.printTooManySeats(maxSeatsPerRow);
            valid = false;
        }
        return valid;
    }
}
