package gic.project.Printers;

import gic.project.CinemaLayouts.Movie;
import gic.project.CinemaLayouts.Seat;

import java.util.Objects;

public class Printer {

    public void printMovieSeatMapDefinition(){
        System.out.print("Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n");
    }

    public void printWelcomeMessage(Movie movie){
        System.out.printf("Welcome to GIC Cinemas\n"
                + "[1] Book tickets for "
                + movie.getMovieTitle()
                + " ("
                + movie.getAvailableSeats()
                + " seats available)\n"
                + "[2] Check bookings\n"
                + "[3] Exit\n"
                + "Please enter your selection:\n");
    }

    public void printTicketBookingMenu(){
        System.out.print("Enter number of tickets to book, or enter blank to go back to main menu:\n");
    }

    public void printViewBookingMenu(){
        System.out.print("\nEnter booking id, or enter blank to go back to main menu:\n");
    }

    public void printInvalidBookingId(){
        System.out.print("Not a valid bookingId for this movie, please try again.\n");
    }

    public void printGoodbyeMessage(){
        System.out.print("Thank you for using GIC Cinemas system. Bye!\n");
    }

    public void printNotEnoughSeatsAvailable(int availableSeats){
        if (availableSeats == 0 ){
            System.out.println("\nSorry, there are " + availableSeats + " seats available.\n");
        } else {
            System.out.println("\nSorry, there are only " + availableSeats + " seats available.\n");
        }
    }

    public void printNotValidMenuOption(){
        System.out.print("\nNot a valid option.\n\n");
    }

    public void printConfirmReservation(){
        System.out.print("\nEnter blank to accept seat selection, or enter new seating position:\n");
    }

    public void printBookingReserved(Movie movie, int numberOfSeats){
        System.out.print("\nSuccessfully reserved " + numberOfSeats + " " + movie.getMovieTitle() + " tickets.");
    }

    public void printBookingIdConfirmed(String bookingId){
        System.out.println("\nBooking id: " + bookingId + " confirmed.\n");
    }

    public void printInvalidInput(){
        System.out.print("Invalid input.\n");
    }

    public void printTooManyRows(int maxRows){
        System.out.print("Invalid input: Too many rows, maximum rows are " + maxRows + ".\n");
    }

    public void printTooManySeats(int maxSeatsPerRow){
        System.out.print("Invalid input: Too many seats per row, maximum seats per row are " + maxSeatsPerRow + ".\n");
    }

    public void printInvalidSeatBooking(){
        System.out.print("Invalid seat.\n\nEnter new seating position:\n");
    }

    public void printReservation(Movie movie, Seat[][] seatMap, String bookingId){
        printBookingId(bookingId);
        printScreenAreaFormatted(seatMap);
        int rowIndex = 0;
        for (Seat[] seats : seatMap) {
            System.out.println();
            System.out.print(movie.getRowLabel(rowIndex++).get() + " ");
            for (Seat seat : seats) {
                if (seat.isBooked() && Objects.equals(seat.getBookingId(), bookingId)) {
                    printBookedSeat();
                } else if (seat.isBooked()) {
                    printUnavailableSeat();
                } else {
                    printAvailableSeat();
                }
            }
        }
        System.out.println();
        System.out.print("  ");
        for (int i = 0 ; i < seatMap[0].length ; i++) {
            System.out.print(" " + (i + 1) + " ");
        }
        System.out.println();
    }


    public void printBooking(Movie movie, String bookingId){
        Seat[][] seatMap = movie.getSeatMap();
        printBookingId(bookingId);
        printScreenAreaFormatted(seatMap);
        int rowIndex = 0;
        for (Seat[] seats : seatMap) {
            System.out.println();
            System.out.print(movie.getRowLabel(rowIndex++).get() + " ");
            for (Seat seat : seats) {
                if (seat.isBooked() && Objects.equals(seat.getBookingId(), bookingId)) {
                    printBookedSeat();
                } else if (seat.isBooked()) {
                    printUnavailableSeat();
                } else {
                    printAvailableSeat();
                }
            }
        }
        System.out.println();
        System.out.print("  ");
        for (int i = 0 ; i < seatMap[0].length ; i++) {
            System.out.print(" " + (i + 1) + " ");
        }
        System.out.println();
    }

    private void printScreenAreaFormatted(Seat[][] seatMap){
        int seatMapWidth = seatMap[0].length*3 + 3;
        System.out.println("Selected seats:\n");
        String title = "S C R E E N";
        int titleLength = title.length();
        int padding = (seatMapWidth - titleLength) / 2;
        if (padding < 0)
            padding = padding * -1;
        String separator = "-".repeat(seatMapWidth);
        System.out.println(" ".repeat(padding) + title);
        System.out.print(separator);
    }

    private void printBookingId(String bookingId){
        System.out.print("\nBooking id: " + bookingId + "\n");
    }

    private void printAvailableSeat(){
        System.out.print(" . ");
    }

    private void printUnavailableSeat(){
        System.out.print(" # ");
    }

    private void printBookedSeat(){
        System.out.print(" o ");
    }
}
