package gic.project.Printers;

import gic.project.CinemaLayouts.Movie;
import gic.project.Managers.BookingManager;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

class PrinterTest {

    Printer printer = new Printer();

    @Test
    void testPrintBookingFormatIsCorrect(){
        Movie movie = new Movie("testPrintBookingFormatIsCorrect", 4, 4);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        printer.printBooking(movie, "");
        String expectedOutput = "\nBooking id: \n" +
                "Selected seats:\n" +
                "\n" +
                "  S C R E E N\n" +
                "---------------\n" +
                "D  .  .  .  . \n" +
                "C  .  .  .  . \n" +
                "B  .  .  .  . \n" +
                "A  .  .  .  . \n" +
                "   1  2  3  4 \n";
        assertEquals(expectedOutput.replace("\r\n", "\n"), outputStream.toString().replace("\r\n", "\n"));
    }

    @Test
    void testPrintBookingAllocationsAreCorrect(){
        Movie movie = new Movie("testPrintBookingAllocationsAreCorrect", 1, 4);
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        movie.generateBookingId();
        BookingManager bookingManager = new BookingManager(movie);
        bookingManager.bookDefaultSeats(movie.getSeatMap(), 1, 0);
        movie.generateBookingId();
        bookingManager.bookDefaultSeats(movie.getSeatMap(), 1, 0);
        printer.printBooking(movie, "GIC0002");

        String expectedOutput = "\nBooking id: GIC0002\n" +
                "Selected seats:\n" +
                "\n" +
                "  S C R E E N\n" +
                "---------------\n" +
                "A  .  o  #  . \n" +
                "   1  2  3  4 \n";

        assertEquals(expectedOutput.replace("\r\n", "\n"), outputStream.toString().replace("\r\n", "\n"));
    }

}