package gic.project.Managers;

import gic.project.CinemaLayouts.Movie;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

class BookingManagerTest {

    @Test
    void testDefaultBookingIsPopulatedFromTheMiddleEqualSeatsInRow(){
        Movie movie = new Movie("testDefaultBookingIsPopulatedFromTheMiddleEqualSeatsInRow", 1, 6);
        BookingManager bookingManager = new BookingManager(movie);
        movie.generateBookingId();
        movie.setSeatMap(bookingManager.bookDefaultSeats(movie.getSeatMap(), 4, movie.getRows() - 1));

        Assertions.assertFalse(movie.getSeatMap()[0][0].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][1].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][2].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][3].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][4].isBooked());
        Assertions.assertFalse(movie.getSeatMap()[0][5].isBooked());
    }

    @Test
    void testDefaultBookingIsPopulatedFromTheMiddleUnequalSeatsInRow(){
        Movie movie = new Movie("testDefaultBookingIsPopulatedFromTheMiddleUnequalSeatsInRow", 1, 7);
        BookingManager bookingManager = new BookingManager(movie);
        movie.generateBookingId();
        movie.setSeatMap(bookingManager.bookDefaultSeats(movie.getSeatMap(), 4, movie.getRows() - 1));

        Assertions.assertFalse(movie.getSeatMap()[0][0].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][1].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][2].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][3].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][4].isBooked());
        Assertions.assertFalse(movie.getSeatMap()[0][5].isBooked());
        Assertions.assertFalse(movie.getSeatMap()[0][6].isBooked());
    }

    @Test
    void testDefaultBookingIsPopulatedFromTheBackRow(){
        Movie movie = new Movie("testDefaultBookingIsPopulatedFromTheBackRow", 3, 10);
        BookingManager bookingManager = new BookingManager(movie);
        movie.generateBookingId();
        movie.setSeatMap(bookingManager.bookDefaultSeats(movie.getSeatMap(), 10, movie.getRows() - 1));
        Assertions.assertTrue(movie.getSeatMap()[2][0].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][9].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][5].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][4].isBooked());

        Assertions.assertFalse(movie.getSeatMap()[1][0].isBooked());
        Assertions.assertFalse(movie.getSeatMap()[1][9].isBooked());
        Assertions.assertFalse(movie.getSeatMap()[0][5].isBooked());
        Assertions.assertFalse(movie.getSeatMap()[0][4].isBooked());
        Assertions.assertFalse(movie.getSeatMap()[0][0].isBooked());
        Assertions.assertFalse(movie.getSeatMap()[0][9].isBooked());
    }

    @Test
    void testDefaultBookingOverflowsFromBackToFront(){
        Movie movie = new Movie("testDefaultBookingOverflowsFromBackToFront", 3, 10);
        BookingManager bookingManager = new BookingManager(movie);
        movie.generateBookingId();
        movie.setSeatMap(bookingManager.bookDefaultSeats(movie.getSeatMap(), 22, movie.getRows() - 1));

        Assertions.assertTrue(movie.getSeatMap()[2][0].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][9].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[1][0].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[1][9].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][5].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][4].isBooked());

        Assertions.assertFalse(movie.getSeatMap()[0][0].isBooked());
        Assertions.assertFalse(movie.getSeatMap()[0][9].isBooked());
    }

    @Test
    void testDefaultBookingOverflowsToTheBackOfCinemaIfFrontRowIsFull(){
        Movie movie = new Movie("testDefaultBookingOverflowsToTheBackOfCinemaIfFrontRowIsFull", 3, 10);
        BookingManager bookingManager = new BookingManager(movie);
        movie.generateBookingId();
        movie.setSeatMap(bookingManager.bookDefaultSeats(movie.getSeatMap(), 12, 0));

        Assertions.assertTrue(movie.getSeatMap()[0][4].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][5].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][0].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][9].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][4].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][5].isBooked());

        Assertions.assertFalse(movie.getSeatMap()[2][9].isBooked());
        Assertions.assertFalse(movie.getSeatMap()[2][9].isBooked());
    }

    @Test
    void testBookCustomSeatsFillsToTheRight(){
        Movie movie = new Movie("testBookCustomSeatsFillsToTheRight", 3, 10);
        BookingManager bookingManager = new BookingManager(movie);
        movie.generateBookingId();
        movie.setSeatMap(bookingManager.bookCustomSeats(movie.getSeatMap(), 4, 2, 0));

        Assertions.assertTrue(movie.getSeatMap()[2][0].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][1].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][2].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][3].isBooked());
    }

    @Test
    void testBookCustomSeatsOverFlowsToTheNextRow(){
        Movie movie = new Movie("testBookCustomSeatsOverFlowsToTheNextRow", 3, 10);
        BookingManager bookingManager = new BookingManager(movie);
        movie.generateBookingId();
        movie.setSeatMap(bookingManager.bookDefaultSeats(movie.getSeatMap(), 8, movie.getRows() - 1));
        movie.setSeatMap(bookingManager.bookCustomSeats(movie.getSeatMap(), 4, 2, 0));

        Assertions.assertTrue(movie.getSeatMap()[2][0].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][7].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][8].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][9].isBooked());
        Assertions.assertTrue((movie.getSeatMap()[1][4].isBooked()));
        Assertions.assertTrue((movie.getSeatMap()[1][5].isBooked()));

        Assertions.assertFalse((movie.getSeatMap()[1][3].isBooked()));
        Assertions.assertFalse((movie.getSeatMap()[1][6].isBooked()));
    }

    @Test
    void testBookCustomSeatsOverflowsToTheBackOfCinemaIfFrontRowIsFull(){
        Movie movie = new Movie("testBookCustomSeatsOverflowsToTheBackOfCinemaIfFrontRowIsFull", 3, 10);
        BookingManager bookingManager = new BookingManager(movie);
        movie.generateBookingId();
        movie.setSeatMap(bookingManager.bookDefaultSeats(movie.getSeatMap(), 8, 0));
        movie.setSeatMap(bookingManager.bookCustomSeats(movie.getSeatMap(), 4, 0, 0));

        Assertions.assertTrue(movie.getSeatMap()[0][0].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[0][9].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][4].isBooked());
        Assertions.assertTrue(movie.getSeatMap()[2][5].isBooked());
    }

}