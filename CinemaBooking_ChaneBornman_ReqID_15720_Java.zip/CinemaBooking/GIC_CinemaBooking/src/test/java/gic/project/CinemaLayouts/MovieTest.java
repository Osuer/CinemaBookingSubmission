package gic.project.CinemaLayouts;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MovieTest {

    @Test
    void testInitSeatMapSizingIsCorrect(){
        Movie movie = new Movie("testInitSeatMapSizingIsCorrect", 1, 1);

        assertEquals(1, movie.getSeatMap().length);
        assertEquals(1, movie.getSeatMap()[0].length);

        movie = new Movie("testInitSeatMapSizingIsCorrect", 8, 10);

        assertEquals(8, movie.getSeatMap().length);
        assertEquals(10, movie.getSeatMap()[0].length);
    }

    @Test
    void testGetLastBookingIdGetsTheLatestBooking(){
        Movie movie = new Movie("testGetLastBookingIdGetsTheLatestBooking", 1, 1);
        movie.generateBookingId();

        assertEquals("GIC0001", movie.getLastBookingId());

        for (int i = 0; i < 3; i++) {
            movie.generateBookingId();
        }

        assertEquals("GIC0004", movie.getLastBookingId());
    }

    @Test
    void testBookingIdGenerationFormatIsCorrect(){
        Movie movie = new Movie("testBookingIdGenerationFormatIsCorrect", 1, 1);
        movie.generateBookingId();

        assertEquals("GIC0001", movie.getLastBookingId());
    }

    @Test
    void testIdGenerationCanIncrementTo2Digits(){
        Movie movie = new Movie("testIdGenerationCanIncrementTo2Digits", 1, 1);
        for (int i = 0; i < 11; i++) {
          movie.generateBookingId();
        }

        assertEquals("GIC0011", movie.getLastBookingId());
    }

    @Test
    void testIdGenerationCanIncrementTo3Digits(){
        Movie movie = new Movie("testIdGenerationCanIncrementTo3Digits", 1, 1);
        for (int i = 0; i < 101; i++) {
            movie.generateBookingId();
        }

        assertEquals("GIC0101", movie.getLastBookingId());
    }

    @Test
    void testCopySeatMapProducesActualNewCopyInMemoryAndNotReferenceToSeatmapStoredInClass(){
        Movie movie = new Movie("testCopySeatMapProducesActualNewCopyInMemoryAndNotReferenceToSeatmapStoredInClass", 1, 1);
        Seat[][] copy = movie.copySeatMap();
        movie.getSeatMap()[0][0].setBooked(true);

        assertNotEquals(movie.getSeatMap()[0][0].isBooked(), copy[0][0].isBooked());
    }

    @Test
    void testGetRowIndexProducesCorrectRowNumber(){
        Movie movie = new Movie("testGetRowIndexProducesCorrectRowNumber", 5, 5);

        if (movie.getRowIndex('A').isPresent()){
            assertEquals(4, movie.getRowIndex('A').get());
        } else {
            fail("Row character not present.");
        }

        if (movie.getRowIndex('C').isPresent()){
            assertEquals(2, movie.getRowIndex('C').get());
        } else {
            fail("Row character not present.");
        }

        if (movie.getRowIndex('E').isPresent()){
            assertEquals(0, movie.getRowIndex('E').get());
        } else {
            fail("Row character not present.");
        }
    }

    @Test
    void testGetRowIndexProducesNegativeWhenRowDoesNotExist(){
        Movie movie = new Movie("testGetRowIndexProducesNegativeWhenRowDoesNotExist", 5, 5);

        assertTrue(movie.getRowIndex('F').isEmpty());
    }

    @Test
    void testGetRowLabelProducesCorrectRowCharacter(){
        Movie movie = new Movie("testGetRowLabelProducesCorrectRowCharacter", 5, 5);

        if (movie.getRowLabel(0).isPresent()){
            assertEquals('E', movie.getRowLabel(0).get());
        } else {
            fail("Row number not present.");
        }

        if (movie.getRowLabel(2).isPresent()){
            assertEquals('C', movie.getRowLabel(2).get());
        } else {
            fail("Row number not present.");
        }

        if (movie.getRowLabel(4).isPresent()){
            assertEquals('A', movie.getRowLabel(4).get());
        } else {
            fail("Row number not present.");
        }
    }

    @Test
    void testGetRowLabelProducesCharacter(){
        Movie movie = new Movie("testGetRowLabelProducesCorrectRowCharacter", 5, 5);

        assertTrue(movie.getRowLabel(6).isEmpty());
        assertTrue(movie.getRowLabel(-1).isEmpty());
    }

}