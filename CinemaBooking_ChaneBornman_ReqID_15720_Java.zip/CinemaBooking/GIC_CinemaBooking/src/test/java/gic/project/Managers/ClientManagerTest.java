package gic.project.Managers;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
class ClientManagerTest {

    @Test
    void testValidInputsForMovieDefinitionRegex(){
        ClientManager clientManager = new ClientManager();
        Map<String, String> regexMap = clientManager.getRegexPatternsForValidInputs();
        String movieDefinitionRegex = regexMap.get("Movie Definition");
        Assertions.assertTrue("Inception 8 10".matches(movieDefinitionRegex));
        Assertions.assertTrue("String 2 8 10".matches(movieDefinitionRegex));
        Assertions.assertTrue("String 8 String 8 10".matches(movieDefinitionRegex));
        Assertions.assertTrue("String String 8 10".matches(movieDefinitionRegex));
        Assertions.assertTrue("String String 2 8 10".matches(movieDefinitionRegex));
        Assertions.assertTrue("String 2 String 2 8 10".matches(movieDefinitionRegex));
        Assertions.assertTrue("String 2 String 2 String 8 10".matches(movieDefinitionRegex));
        Assertions.assertTrue("2 String 2 String 8 10".matches(movieDefinitionRegex));

        Assertions.assertFalse("String".matches(movieDefinitionRegex));
        Assertions.assertFalse("String 4".matches(movieDefinitionRegex));
        Assertions.assertFalse("4 10".matches(movieDefinitionRegex));
        Assertions.assertFalse("String 4 10 String".matches(movieDefinitionRegex));
        Assertions.assertFalse("String 0 9".matches(movieDefinitionRegex));
        Assertions.assertFalse("String 9 0".matches(movieDefinitionRegex));
        Assertions.assertFalse("String 4 -10".matches(movieDefinitionRegex));
        Assertions.assertFalse("String -4 10".matches(movieDefinitionRegex));
    }

    @Test
    void testValidInputsForSeatBookingRegex(){
        ClientManager clientManager = new ClientManager();
        Map<String, String> regexMap = clientManager.getRegexPatternsForValidInputs();
        String seatBookingRegex = regexMap.get("Seat Booking");
        Assertions.assertTrue("B03".matches(seatBookingRegex));
        Assertions.assertTrue("B11".matches(seatBookingRegex));

        Assertions.assertFalse("B6".matches(seatBookingRegex));
        Assertions.assertFalse("B006".matches(seatBookingRegex));
        Assertions.assertFalse("B 06".matches(seatBookingRegex));
        Assertions.assertFalse("BB06".matches(seatBookingRegex));
        Assertions.assertFalse("6B".matches(seatBookingRegex));
    }

    @Test
    void testValidInputsForNumberOfSeatsRegex(){
        ClientManager clientManager = new ClientManager();
        Map<String, String> regexMap = clientManager.getRegexPatternsForValidInputs();
        String seatBookingRegex = regexMap.get("Number of Seats");
        Assertions.assertTrue("1".matches(seatBookingRegex));
        Assertions.assertTrue("11".matches(seatBookingRegex));

        Assertions.assertFalse("0".matches(seatBookingRegex));
        Assertions.assertFalse("-1".matches(seatBookingRegex));
        Assertions.assertFalse("Two".matches(seatBookingRegex));
        Assertions.assertFalse("02".matches(seatBookingRegex));
    }

    @Test
    void testMovieDefinitionOutput(){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        String userInput = "Movie 3 3\n3\n";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(inputStream);
        ClientManager clientManager = new ClientManager();
        clientManager.initiateUserInteraction();
        String expectedOutput = "Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (9 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Thank you for using GIC Cinemas system. Bye!\n";

        assertEquals(expectedOutput.replace("\r\n", "\n"), outputStream.toString().replace("\r\n", "\n"));
    }

    @Test
    void testMovieDefinitionTooManyRows (){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        String userInput = "Movie 27 2\nMovie 3 3\n3\n";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(inputStream);
        ClientManager clientManager = new ClientManager();
        clientManager.initiateUserInteraction();
        String expectedOutput = "Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n" +
                "Invalid input: Too many rows, maximum rows are 26.\n" +
                "Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (9 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Thank you for using GIC Cinemas system. Bye!\n";

        assertEquals(expectedOutput.replace("\r\n", "\n"), outputStream.toString().replace("\r\n", "\n"));
    }

    @Test
    void testMovieDefinitionTooManySeatsPerRows (){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        String userInput = "Movie 3 51\nMovie 3 3\n3\n";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(inputStream);
        ClientManager clientManager = new ClientManager();
        clientManager.initiateUserInteraction();
        String expectedOutput = "Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n" +
                "Invalid input: Too many seats per row, maximum seats per row are 50.\n" +
                "Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (9 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Thank you for using GIC Cinemas system. Bye!\n";

        assertEquals(expectedOutput.replace("\r\n", "\n"), outputStream.toString().replace("\r\n", "\n"));
    }

    @Test
    void testMovieDefaultBookingAccepted(){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        String userInput = "Movie 3 3\n1\n4\n \n3";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(inputStream);
        ClientManager clientManager = new ClientManager();
        clientManager.initiateUserInteraction();
        String expectedOutput = "Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (9 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Enter number of tickets to book, or enter blank to go back to main menu:\n" +
                "\n" +
                "Successfully reserved 4 Movie tickets.\n" +
                "Booking id: GIC0001\n" +
                "Selected seats:\n" +
                "\n" +
                "S C R E E N\n" +
                "------------\n" +
                "C  .  .  . \n" +
                "B  .  o  . \n" +
                "A  o  o  o \n" +
                "   1  2  3 \n" +
                "\n" +
                "Enter blank to accept seat selection, or enter new seating position:\n" +
                "\n" +
                "Booking id: GIC0001 confirmed.\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (5 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Thank you for using GIC Cinemas system. Bye!\n";
        assertEquals(expectedOutput.replace("\r\n", "\n"), outputStream.toString().replace("\r\n", "\n"));
    }

    @Test
    void testMovieDefaultBookingNotAccepted(){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        String userInput = "Movie 3 3\n1\n4\nB01\n \n3";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(inputStream);
        ClientManager clientManager = new ClientManager();
        clientManager.initiateUserInteraction();
        String expectedOutput = "Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (9 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Enter number of tickets to book, or enter blank to go back to main menu:\n" +
                "\n" +
                "Successfully reserved 4 Movie tickets.\n" +
                "Booking id: GIC0001\n" +
                "Selected seats:\n" +
                "\n" +
                "S C R E E N\n" +
                "------------\n" +
                "C  .  .  . \n" +
                "B  .  o  . \n" +
                "A  o  o  o \n" +
                "   1  2  3 \n" +
                "\n" +
                "Enter blank to accept seat selection, or enter new seating position:\n" +
                "\n" +
                "Booking id: GIC0001\n" +
                "Selected seats:\n" +
                "\n" +
                "S C R E E N\n" +
                "------------\n" +
                "C  .  o  . \n" +
                "B  o  o  o \n" +
                "A  .  .  . \n" +
                "   1  2  3 \n" +
                "\n" +
                "Enter blank to accept seat selection, or enter new seating position:\n" +
                "\n" +
                "Booking id: GIC0001 confirmed.\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (5 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Thank you for using GIC Cinemas system. Bye!\n";
        assertEquals(expectedOutput.replace("\r\n", "\n"), outputStream.toString().replace("\r\n", "\n"));
    }

    @Test
    void testMovieBookingPrintsErrorOnNonValidNumberOfTicketsToBook(){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        String userInput = "Movie 3 3\n1\n0\n \n3";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(inputStream);
        ClientManager clientManager = new ClientManager();
        clientManager.initiateUserInteraction();
        String expectedOutput = "Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (9 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Enter number of tickets to book, or enter blank to go back to main menu:\n" +
                "Invalid input.\n" +
                "Enter number of tickets to book, or enter blank to go back to main menu:\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (9 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Thank you for using GIC Cinemas system. Bye!\n";
        assertEquals(expectedOutput.replace("\r\n", "\n"), outputStream.toString().replace("\r\n", "\n"));
    }

    @Test
    void testMovieBookingPrintsErrorOnTooManyTicketsToBook(){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        String userInput = "Movie 3 3\n1\n10\n \n3";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(inputStream);
        ClientManager clientManager = new ClientManager();
        clientManager.initiateUserInteraction();
        String expectedOutput = "Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (9 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Enter number of tickets to book, or enter blank to go back to main menu:\n" +
                "\n" +
                "Sorry, there are only 9 seats available.\n" +
                "\n" +
                "Enter number of tickets to book, or enter blank to go back to main menu:\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (9 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Thank you for using GIC Cinemas system. Bye!\n";
        assertEquals(expectedOutput.replace("\r\n", "\n"), outputStream.toString().replace("\r\n", "\n"));
    }

    @Test
    void testCheckBooking(){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        String userInput = "Movie 3 3\n1\n4\n \n2\nGIC0001\n \n3";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(inputStream);
        ClientManager clientManager = new ClientManager();
        clientManager.initiateUserInteraction();
        String expectedOutput = "Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (9 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Enter number of tickets to book, or enter blank to go back to main menu:\n" +
                "\n" +
                "Successfully reserved 4 Movie tickets.\n" +
                "Booking id: GIC0001\n" +
                "Selected seats:\n" +
                "\n" +
                "S C R E E N\n" +
                "------------\n" +
                "C  .  .  . \n" +
                "B  .  o  . \n" +
                "A  o  o  o \n" +
                "   1  2  3 \n" +
                "\n" +
                "Enter blank to accept seat selection, or enter new seating position:\n" +
                "\n" +
                "Booking id: GIC0001 confirmed.\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (5 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "\n" +
                "Enter booking id, or enter blank to go back to main menu:\n" +
                "\n" +
                "Booking id: GIC0001\n" +
                "Selected seats:\n" +
                "\n" +
                "S C R E E N\n" +
                "------------\n" +
                "C  .  .  . \n" +
                "B  .  o  . \n" +
                "A  o  o  o \n" +
                "   1  2  3 \n" +
                "\n" +
                "Enter booking id, or enter blank to go back to main menu:\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Movie (5 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Thank you for using GIC Cinemas system. Bye!\n";
        assertEquals(expectedOutput.replace("\r\n", "\n"), outputStream.toString().replace("\r\n", "\n"));
    }

    @Test
    void testAcceptanceTest(){
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        String userInput = "Inception 8 10\n1\n4\nB03\n \n1\n77\n12\nB05\n \n2\nGIC0001\nGIC0002\n \n3";
        ByteArrayInputStream inputStream = new ByteArrayInputStream(userInput.getBytes());
        System.setIn(inputStream);
        ClientManager clientManager = new ClientManager();
        clientManager.initiateUserInteraction();
        String expectedOutput = "Please define movie title and seating map in [Title] [Row] [SeatsPerRow] format:\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Inception (80 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Enter number of tickets to book, or enter blank to go back to main menu:\n" +
                "\n" +
                "Successfully reserved 4 Inception tickets.\n" +
                "Booking id: GIC0001\n" +
                "Selected seats:\n" +
                "\n" +
                "           S C R E E N\n" +
                "---------------------------------\n" +
                "H  .  .  .  .  .  .  .  .  .  . \n" +
                "G  .  .  .  .  .  .  .  .  .  . \n" +
                "F  .  .  .  .  .  .  .  .  .  . \n" +
                "E  .  .  .  .  .  .  .  .  .  . \n" +
                "D  .  .  .  .  .  .  .  .  .  . \n" +
                "C  .  .  .  .  .  .  .  .  .  . \n" +
                "B  .  .  .  .  .  .  .  .  .  . \n" +
                "A  .  .  .  o  o  o  o  .  .  . \n" +
                "   1  2  3  4  5  6  7  8  9  10 \n" +
                "\n" +
                "Enter blank to accept seat selection, or enter new seating position:\n" +
                "\n" +
                "Booking id: GIC0001\n" +
                "Selected seats:\n" +
                "\n" +
                "           S C R E E N\n" +
                "---------------------------------\n" +
                "H  .  .  .  .  .  .  .  .  .  . \n" +
                "G  .  .  .  .  .  .  .  .  .  . \n" +
                "F  .  .  .  .  .  .  .  .  .  . \n" +
                "E  .  .  .  .  .  .  .  .  .  . \n" +
                "D  .  .  .  .  .  .  .  .  .  . \n" +
                "C  .  .  .  .  .  .  .  .  .  . \n" +
                "B  .  .  o  o  o  o  .  .  .  . \n" +
                "A  .  .  .  .  .  .  .  .  .  . \n" +
                "   1  2  3  4  5  6  7  8  9  10 \n" +
                "\n" +
                "Enter blank to accept seat selection, or enter new seating position:\n" +
                "\n" +
                "Booking id: GIC0001 confirmed.\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Inception (76 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Enter number of tickets to book, or enter blank to go back to main menu:\n" +
                "\n" +
                "Sorry, there are only 76 seats available.\n" +
                "\n" +
                "Enter number of tickets to book, or enter blank to go back to main menu:\n" +
                "\n" +
                "Successfully reserved 12 Inception tickets.\n" +
                "Booking id: GIC0002\n" +
                "Selected seats:\n" +
                "\n" +
                "           S C R E E N\n" +
                "---------------------------------\n" +
                "H  .  .  .  .  .  .  .  .  .  . \n" +
                "G  .  .  .  .  .  .  .  .  .  . \n" +
                "F  .  .  .  .  .  .  .  .  .  . \n" +
                "E  .  .  .  .  .  .  .  .  .  . \n" +
                "D  .  .  .  .  .  .  .  .  .  . \n" +
                "C  .  .  .  .  .  .  .  .  .  . \n" +
                "B  .  .  #  #  #  #  o  o  .  . \n" +
                "A  o  o  o  o  o  o  o  o  o  o \n" +
                "   1  2  3  4  5  6  7  8  9  10 \n" +
                "\n" +
                "Enter blank to accept seat selection, or enter new seating position:\n" +
                "\n" +
                "Booking id: GIC0002\n" +
                "Selected seats:\n" +
                "\n" +
                "           S C R E E N\n" +
                "---------------------------------\n" +
                "H  .  .  .  .  .  .  .  .  .  . \n" +
                "G  .  .  .  .  .  .  .  .  .  . \n" +
                "F  .  .  .  .  .  .  .  .  .  . \n" +
                "E  .  .  .  .  .  .  .  .  .  . \n" +
                "D  .  .  .  .  .  .  .  .  .  . \n" +
                "C  .  o  o  o  o  o  o  o  o  . \n" +
                "B  .  .  #  #  #  #  o  o  o  o \n" +
                "A  .  .  .  .  .  .  .  .  .  . \n" +
                "   1  2  3  4  5  6  7  8  9  10 \n" +
                "\n" +
                "Enter blank to accept seat selection, or enter new seating position:\n" +
                "\n" +
                "Booking id: GIC0002 confirmed.\n" +
                "\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Inception (64 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "\n" +
                "Enter booking id, or enter blank to go back to main menu:\n" +
                "\n" +
                "Booking id: GIC0001\n" +
                "Selected seats:\n" +
                "\n" +
                "           S C R E E N\n" +
                "---------------------------------\n" +
                "H  .  .  .  .  .  .  .  .  .  . \n" +
                "G  .  .  .  .  .  .  .  .  .  . \n" +
                "F  .  .  .  .  .  .  .  .  .  . \n" +
                "E  .  .  .  .  .  .  .  .  .  . \n" +
                "D  .  .  .  .  .  .  .  .  .  . \n" +
                "C  .  #  #  #  #  #  #  #  #  . \n" +
                "B  .  .  o  o  o  o  #  #  #  # \n" +
                "A  .  .  .  .  .  .  .  .  .  . \n" +
                "   1  2  3  4  5  6  7  8  9  10 \n" +
                "\n" +
                "Enter booking id, or enter blank to go back to main menu:\n" +
                "\n" +
                "Booking id: GIC0002\n" +
                "Selected seats:\n" +
                "\n" +
                "           S C R E E N\n" +
                "---------------------------------\n" +
                "H  .  .  .  .  .  .  .  .  .  . \n" +
                "G  .  .  .  .  .  .  .  .  .  . \n" +
                "F  .  .  .  .  .  .  .  .  .  . \n" +
                "E  .  .  .  .  .  .  .  .  .  . \n" +
                "D  .  .  .  .  .  .  .  .  .  . \n" +
                "C  .  o  o  o  o  o  o  o  o  . \n" +
                "B  .  .  #  #  #  #  o  o  o  o \n" +
                "A  .  .  .  .  .  .  .  .  .  . \n" +
                "   1  2  3  4  5  6  7  8  9  10 \n" +
                "\n" +
                "Enter booking id, or enter blank to go back to main menu:\n" +
                "Welcome to GIC Cinemas\n" +
                "[1] Book tickets for Inception (64 seats available)\n" +
                "[2] Check bookings\n" +
                "[3] Exit\n" +
                "Please enter your selection:\n" +
                "Thank you for using GIC Cinemas system. Bye!\n";
        assertEquals(expectedOutput.replace("\r\n", "\n"), outputStream.toString().replace("\r\n", "\n"));
    }


}